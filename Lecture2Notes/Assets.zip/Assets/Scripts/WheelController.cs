using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WheelController : MonoBehaviour
{
    public bool driveable = false;
    [Header("Wheel Wrappers")]
    public Transform frontLeftWheelWrapper;
    public Transform frontRightWheelWrapper;
    public Transform rearLeftWheelWrapper;
    public Transform rearRightWheelWrapper;

    [Header("Wheel Colliders")]
    [SerializeField] private WheelCollider frontLeft;
    [SerializeField] private WheelCollider frontRight;
    [SerializeField] private WheelCollider rearLeft;
    [SerializeField] private WheelCollider rearRight;
    [SerializeField] private Rigidbody rb;
    [SerializeField] private CarIsGrounded carIsGrounded;

    

    [Header("Driving Specs")]
    public float acceleration = 500f;
    public float breakingForce = 300f;
    public float maxTurnAngle = 15f;
    [SerializeField] float jumpForce = 10f;

    private float currentAcceleration = 0f;
    private float currentBreakForce = 0f;
    private float currentTurnAngle = 0f;
   
    private void Start()
    {
        
    }
    void jump()
    {
        if (Input.GetKeyDown(KeyCode.CapsLock))
        {
            rb.AddForce(transform.up * jumpForce, ForceMode.Impulse);
        }
    }
    private void Update()
    {
        if (carIsGrounded.GroundCheck() == true)
        {
            jump();
            if (Input.GetKey(KeyCode.W))
            {
                currentAcceleration = acceleration * -Input.GetAxis("Vertical") * Time.deltaTime;
                rb.AddForce(transform.forward * currentAcceleration, ForceMode.Impulse);
            }
            else if (Input.GetKey(KeyCode.S))
            {
                currentAcceleration = acceleration * -Input.GetAxis("Vertical") * Time.deltaTime;
                rb.AddForce(transform.forward * currentAcceleration, ForceMode.Impulse);
            }

        }
        /*else
        {
            if (Input.GetKey(KeyCode.W))
            {

                transform.RotateAround(transform.position, -transform.right, Time.deltaTime * 180f);

            }
            else if (Input.GetKey(KeyCode.S))
            {
                transform.RotateAround(transform.position, transform.right, Time.deltaTime * 90f);

            }
            if (Input.GetKey(KeyCode.Space))
            {
                if (Input.GetKey(KeyCode.A))
                {
                    transform.RotateAround(transform.position, -transform.up, Time.deltaTime * 100f);
                }
                else if (Input.GetKey(KeyCode.D))
                {
                    transform.RotateAround(transform.position, transform.up, Time.deltaTime * 100f);
                }
            }
            else
            {
                if (Input.GetKey(KeyCode.A))
                {
                    transform.RotateAround(transform.position, -transform.forward, Time.deltaTime * 135f);
                }
                else if (Input.GetKey(KeyCode.D))
                {
                    transform.RotateAround(transform.position, transform.forward, Time.deltaTime * 135f);
                }
            }


        }
*/

    }

    private void FixedUpdate()
    {
        if (carIsGrounded.GroundCheck() == true)
        {
            currentAcceleration = acceleration * -Input.GetAxis("Vertical");
            if (Input.GetKey(KeyCode.B))
            {
                currentBreakForce = breakingForce;
            }
            else
            {
                currentBreakForce = 0f;
            }
            frontRight.motorTorque = currentAcceleration;
            frontLeft.motorTorque = currentAcceleration;
            rearRight.motorTorque = currentAcceleration;
            rearLeft.motorTorque = currentAcceleration;




            currentTurnAngle = maxTurnAngle * Input.GetAxis("Horizontal");
            frontLeft.steerAngle = currentTurnAngle;
            frontRight.steerAngle = currentTurnAngle;
            transform.RotateAround(transform.position, transform.up, Time.deltaTime * currentTurnAngle);
        }
    }
   
}
