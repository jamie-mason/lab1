using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarJump : MonoBehaviour
{
    private CharacterController characterController;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
