using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cameraSwivel : MonoBehaviour
{
    public GameObject player;
    public float distanceFromPlayer = 5f;
    public float smoothSpeed = 0.125f;
    public float height = 2;
    public Vector3 offset;
    private void FixedUpdate()
    {
        
        transform.position = player.transform.position - player.transform.forward * distanceFromPlayer;
        transform.position = new Vector3(transform.position.x, transform.position.y+height, transform.position.z);
        transform.LookAt(player.transform.position);
    }
}
